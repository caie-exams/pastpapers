<?php
	// link to the local webserver localhost
	// the next parameters are the username and password, which were set as cambidge and cambridge when creating the MySQL database
	// the last parameter is the database name which is registration
	$link = mysqli_connect('localhost','cambridge','cambridge','registration');
?>