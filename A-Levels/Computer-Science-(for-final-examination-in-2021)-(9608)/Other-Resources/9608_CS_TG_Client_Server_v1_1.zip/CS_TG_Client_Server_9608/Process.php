<html>
<body>

<H1>Your registration has passed to the server for processing.</H1>

<?php 
//validation of the form data
$invalid = False;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//fname and lname presence check
	if (empty($_POST["fname"]) or empty($_POST["lname"])){
		print "You must enter the both the first name and last name<br>";
		$invalid = True;
	} else {
	$fname = $_POST["fname"];
	$lname = $_POST["lname"];
	}
	//email presence check and format check
	if (empty($_POST["email"])) {
		print "You must enter the email address<br>";
		$invalid = True;
	} else {
		$email = $_POST["email"];
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			print "Invalid email format<br>";
			$invalid = True;
		}
	}
	//check terms box
	if (!isset($_POST["terms"])) {
		print "You must agrees to the terms and conditions<br>";
		$invalid = True;
	}
}
if ($invalid == True) {
	exit("Due to errors the data will not be added to the system<br>");
}

?>

<?php
	// this runs the script in connection.php which makes the connection to the database
	require_once("connection.php");
	// an SQL query is written
	// this query is to INSERT the three fields into the customers table
	// there is no need to add the CustomerID field from the table as its properties were set as a key field auto increment
	$query = "INSERT INTO customers(FirstName,LastName,Email)"."VALUES"."('$fname','$lname','$email')";
	// execute the SQL string on the database or die if there is an error
	$result = mysqli_query($link,$query) or die(mysqli_error($link));
?>

<p>Thank you for registering correctly for out services</p>
</body>
</html>